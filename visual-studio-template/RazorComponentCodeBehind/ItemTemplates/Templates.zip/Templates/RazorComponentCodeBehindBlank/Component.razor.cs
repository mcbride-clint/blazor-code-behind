﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Components;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : ComponentBase
    {
        
    }
}
